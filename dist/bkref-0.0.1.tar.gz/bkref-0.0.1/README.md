# Basketball Reference Scraper

Scrape data from Basketball Reference.